# police-bot (Playwright microservice)

Deploy this to Railway (Docker) and call `/api/police/submit/tenant` with JSON payload.
Set `API_KEY` and (optionally) `ALLOWED_ORIGINS` in Railway variables.
