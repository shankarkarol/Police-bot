// Playwright route tailored to Rajasthan Police Tenant Uploads
import { Router } from "express";
import { chromium, Page } from "playwright";
import path from "path";
import fs from "fs/promises";
import os from "os";
import crypto from "crypto";
import fetch from "node-fetch";

const router = Router();

type TenantPayload = {
  id_type: string;
  id_number: string;
  first_name: string;
  middle_name?: string;
  last_name: string;
  father_first_name: string;
  father_middle_name?: string;
  father_last_name: string;
  caste: string;
  date_of_birth: string; // DD-MM-YYYY
  tenant_state: string;
  tenant_police_district: string;
  tenant_police_station: string;
  phone: string;
  permanent_address: string;
  passport_photo_url: string;
  combined_id_photo_url?: string;
};

function assertDOB(input: string) {
  if (!/^\d{2}-\d{2}-\d{4}$/.test(input)) {
    throw new Error("DOB must be in DD-MM-YYYY format");
  }
  return input;
}

async function downloadToTemp(urlOrPath: string): Promise<string> {
  if (urlOrPath.startsWith("/") || /^[a-zA-Z]:\\/.test(urlOrPath)) return urlOrPath;
  const res = await fetch(urlOrPath);
  if (!res.ok) throw new Error(`Failed to fetch file: ${urlOrPath}`);
  const buf = Buffer.from(await res.arrayBuffer());
  const ext = (() => {
    try { return path.extname(new URL(urlOrPath).pathname); } catch { return ""; }
  })();
  const tmp = path.join(os.tmpdir(), `upload-${crypto.randomBytes(6).toString("hex")}${ext}`);
  await fs.writeFile(tmp, buf);
  return tmp;
}

async function selectWithPostback(page: Page, selector: string, labelOrValue: string, nextSelector: string) {
  await page.waitForSelector(selector, { state: "visible" });
  try {
    await page.selectOption(selector, { label: labelOrValue });
  } catch {
    await page.selectOption(selector, labelOrValue);
  }
  await page.waitForLoadState("networkidle");
  await page.waitForFunction((sel) => {
    const el = document.querySelector(sel) as HTMLSelectElement | null;
    return el && el.options && el.options.length > 1;
  }, nextSelector);
}

async function safeSelect(page: Page, selector: string, labelOrValue: string) {
  await page.waitForSelector(selector, { state: "visible" });
  try {
    const byLabel = await page.selectOption(selector, { label: labelOrValue });
    if (byLabel && byLabel.length) return;
  } catch {}
  await page.selectOption(selector, labelOrValue);
}

async function typeInto(page: Page, selector: string, text: string) {
  await page.waitForSelector(selector, { state: "visible" });
  await page.fill(selector, "");
  await page.type(selector, text);
}

router.post("/tenant", async (req, res) => {
  const p: TenantPayload = req.body;
  try { assertDOB(p.date_of_birth); } catch (e: any) { return res.status(400).json({ ok: false, error: e.message }); }

  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();

  try {
    await page.goto("https://www.police.rajasthan.gov.in/old/verificationform.aspx", { waitUntil: "domcontentloaded" });
    await page.waitForLoadState("networkidle");

    // Switch to Tenant Uploads tab if present
    const tenantTab = page.locator("text=Tenant Uploads");
    if (await tenantTab.count()) {
      await tenantTab.first().click();
      await page.waitForLoadState("networkidle");
    }

    // Fill fields per provided mapping
    await safeSelect(page, "#ContentPlaceHolder1_ddlTIdCardType", p.id_type);
    await typeInto(page, "#ContentPlaceHolder1_txtTIdNo", p.id_number);
    await safeSelect(page, "#ContentPlaceHolder1_ddlTAvailFrom", "10");
    await safeSelect(page, "#ContentPlaceHolder1_ddlTAvailTo", "18");
    await typeInto(page, "#ContentPlaceHolder1_txtTFirstName", p.first_name);
    if (p.middle_name) await typeInto(page, "#ContentPlaceHolder1_txtTMIddleName", p.middle_name);
    await typeInto(page, "#ContentPlaceHolder1_txtTLastName", p.last_name);
    await typeInto(page, "#ContentPlaceHolder1_txtTFirstFName", p.father_first_name);
    if (p.father_middle_name) await typeInto(page, "#ContentPlaceHolder1_txtTMIddleFName", p.father_middle_name);
    await typeInto(page, "#ContentPlaceHolder1_txtTLastFName", p.father_last_name);
    await safeSelect(page, "#ContentPlaceHolder1_ddlTSex", "Female");
    await safeSelect(page, "#ContentPlaceHolder1_ddlTCaste", p.caste);
    await typeInto(page, "#ContentPlaceHolder1_txtTDOB", p.date_of_birth);

    await selectWithPostback(page, "#ContentPlaceHolder1_ddlTState", p.tenant_state, "#ContentPlaceHolder1_ddlTDistrict");
    await selectWithPostback(page, "#ContentPlaceHolder1_ddlTDistrict", p.tenant_police_district, "#ContentPlaceHolder1_ddlTStation");
    await safeSelect(page, "#ContentPlaceHolder1_ddlTStation", p.tenant_police_station);

    await typeInto(page, "#ContentPlaceHolder1_txtTtntNo", p.phone);
    await typeInto(page, "#ContentPlaceHolder1_txtTAddress", p.permanent_address);
    await safeSelect(page, "#ContentPlaceHolder1_ddlpurpose", "Residence");
    await typeInto(page, "#ContentPlaceHolder1_txtaddressofrented", "XYZ,ASD,JAIPUR");

    await typeInto(page, "#ContentPlaceHolder1_txtLFirstName", "ZZZ");
    await typeInto(page, "#ContentPlaceHolder1_txtLMIddleName", "AAA");
    await typeInto(page, "#ContentPlaceHolder1_txtLLastName", "SSS");
    await typeInto(page, "#ContentPlaceHolder1_txtLFirstFName", "AAA");
    await typeInto(page, "#ContentPlaceHolder1_txtLMIddleFName", "SSS");
    await typeInto(page, "#ContentPlaceHolder1_txtLLastFName", "DDD");
    await typeInto(page, "#ContentPlaceHolder1_txtlandMobno", "9856325698");
    await typeInto(page, "#ContentPlaceHolder1_txtlandPAddress", "XYZ,ASD,JAIPUR");
    await selectWithPostback(page, "#ContentPlaceHolder1_ddlLdistrict", "JAIPUR EAST", "#ContentPlaceHolder1_ddlLStation");
    await safeSelect(page, "#ContentPlaceHolder1_ddlLStation", "RAMNAGARIYA");
    await typeInto(page, "#ContentPlaceHolder1_txtLRefer", "ONLINE");

    const tenantPhoto = await downloadToTemp(p.passport_photo_url);
    await page.setInputFiles("#ContentPlaceHolder1_flTPhoto", tenantPhoto);
    if (p.combined_id_photo_url) {
      const idPhoto = await downloadToTemp(p.combined_id_photo_url);
      await page.setInputFiles("#ContentPlaceHolder1_flTPhotoId", idPhoto);
    }

    // Submit via the exact Save button
    const SAVE_BTN = "#ContentPlaceHolder1_btnTSave";
    await page.waitForSelector(SAVE_BTN, { state: "visible" });
    const prevHtml = await page.content();
    await Promise.all([
      page.click(SAVE_BTN),
      page.waitForLoadState("networkidle"),
      page.waitForFunction((oldHtml) => document.documentElement.innerHTML !== oldHtml, prevHtml, { timeout: 20000 }),
    ]);

    // Look for validation failures quickly
    const hasError = await page.evaluate(() => {
      const summary = document.querySelector(".validation-summary,.ValidationSummary");
      const spans = Array.from(document.querySelectorAll("span"));
      const withErr = spans.some(s => /required|invalid|please select|enter/i.test(s.textContent || ""));
      return !!summary || withErr;
    });
    if (hasError) {
      const errContent = await page.content();
      throw new Error("Validation error on target site. Check required fields. HTML length: " + errContent.length);
    }

    // Extract reference number
    let referenceNo: string | null = null;
    const candidates = ["#ContentPlaceHolder1_lblRefNo", "#ContentPlaceHolder1_lblTRefNo", "#lblRefNo", "#lblReference"];
    for (const sel of candidates) {
      if (await page.locator(sel).count()) {
        const txt = (await page.locator(sel).first().textContent())?.trim() || "";
        const m = txt.match(/([A-Za-z0-9\/\-]+)/);
        if (m) { referenceNo = m[1]; break; }
      }
    }
    if (!referenceNo) {
      const html = await page.content();
      const m = html.match(/Ref(?:erence)?\s*No\.?\s*[:\-]?\s*([A-Za-z0-9\/\-]+)/i);
      if (m) referenceNo = m[1].trim();
    }
    if (!referenceNo) throw new Error("Reference number not found after submission.");

    res.json({ ok: true, referenceNo });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e.message || String(e) });
  } finally {
    await ctx.close().catch(()=>{});
    await browser.close().catch(()=>{});
  }
});

export default router;
