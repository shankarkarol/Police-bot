import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import policeVerificationRouter from "./routes/policeVerification.js";

const app = express();
app.use(bodyParser.json({ limit: "20mb" }));

// Basic CORS allowlist (edit domains as needed)
const allowlist = (process.env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowlist.length === 0 || allowlist.includes(origin)) return cb(null, true);
    return cb(new Error("Not allowed by CORS"));
  }
}));

// Simple API key check (optional but recommended)
app.use((req, res, next) => {
  const required = process.env.API_KEY;
  if (!required) return next();
  const got = req.headers["x-api-key"];
  if (got === required) return next();
  return res.status(401).json({ ok: false, error: "Unauthorized" });
});

app.get("/health", (_req, res) => res.status(200).send("OK"));
app.use("/api/police/submit", policeVerificationRouter);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Police bot running on :${PORT}`));
